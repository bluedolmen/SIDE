/* This notice must be untouched at all times.

Open-jACOB Draw2D
The latest version is available at
http://www.openjacob.org

Copyright (c) 2006 Andreas Herz. All rights reserved.
Created 5. 11. 2006 by Andreas Herz (Web: http://www.freegroup.de )

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/
draw2d.End=function()
{
  draw2d.ImageFigure.call(this,this.type+".png");
  this.inputPort = null;
  this.setDimension(50,50);
  return this;
}

draw2d.End.prototype = new draw2d.ImageFigure;
draw2d.End.prototype.type="End";

draw2d.End.prototype.setWorkflow=function(/*:draw2d.Workflow*/ workflow)
{
  draw2d.ImageFigure.prototype.setWorkflow.call(this,workflow);

  if(workflow!=null && this.inputPort==null)
  {
    // create a new Port element. Ports can be children of "Node" elements.
    // (Inheritance: End->Image->Node->Figure->Object)
    this.inputPort = new draw2d.InputPort();

    // set the paintarea/canvas for this port figure
    this.inputPort.setWorkflow(workflow);

    // set background color of the port
    this.inputPort.setBackgroundColor(new  draw2d.Color(115,115,245));
    this.inputPort.setColor(null);

    ////////////////////////////////////////////////////////////////////
    // INPORTANT: Now you can use the function "End.getPort("input")"!!!
    //            See in index.html for the usage!!!!
    //            This is the main differenct to the "connector_via_api1" demo.
    //
    this.inputPort.setName("input");
    ////////////////////////////////////////////////////////////////////



    // Add the port to this object at the left/middle position
    this.addPort(this.inputPort,0,this.height/2);
  }
}







