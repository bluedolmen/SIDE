<html>
	<head>
		<title>R�pertoire</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>
		<? 
			require("./mysql/mysql_util.php");
		?>
		<div id="data">
			<h1>R�pertoire</h1>
				<? if (isset($_GET["Rpertoire"])) { ?>	
					<div id="component_create">
						<?
							$fromUrl = $_SERVER['HTTP_REFERER'];
							if (strpos($fromUrl,'?')) {
								$param = substr($fromUrl,strpos($fromUrl,'?'),strlen($fromUrl)-1);
							} else {
								$param = "";
							}
							$url = "nwEB8IhcRP.php".$param;
						?>
						<form method="POST" action="<? echo $url; ?>">
						<table class="table_edit">
						<?
							mysql_connect($host, $user, $password);
							mysql_select_db($db);
							if (isset($_GET["idObject"])) {
								$idObject = $_GET["idObject"];
								$sql = "SELECT "
									." nom"
									.","
									." id_fp94N3ubdV"
								    ." FROM Rpertoire"
									." WHERE id_fp94N3ubdV=$idObject;";
								$result = mysql_query($sql);
							 	$data = mysql_fetch_array($result);
							 }
						?>
							<tr>
								<td class="property_name">nom</td>
								<td><input 
										type="text" 
										name="nom"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['nom']?>"
										<? } ?>
									/></td>
							</tr>
						<?
							$allJoinTable = array(); 
						?>
						</table>
						<input type="hidden" name="table_name" value="Rpertoire"/>
						<input type="hidden" name="table_fields" value="nom"/>
						<input type="hidden" name="table_relationships" value="<? echo implode(';',$allJoinTable)?>"/>
						<input type="hidden" name="idFieldName" value="id_fp94N3ubdV"/>
						<? if (isset($_GET["idObject"])) {?>
							<input type="hidden" name="updateObject" value="<? echo $data['id_fp94N3ubdV']?>"/>
							<input type="submit" value="Update"/>
						<? } else { ?>
							<input type="hidden" name="createObject" value="1"/>			
							<input type="submit" value="Create"/>
						<? } ?>			
						</form>
					</div>
				<? } ?>
		</div>
	</body>
</html>