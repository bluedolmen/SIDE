<html>
	<head>
		<title>Fiche</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>
		<? 
			require("./mysql/mysql_util.php");
		?>
		<div id="data">
			<h1>Fiche</h1>
				<? if (isset($_GET["Fiche"])) { ?>	
					<div id="component_create">
						<?
							$fromUrl = $_SERVER['HTTP_REFERER'];
							if (strpos($fromUrl,'?')) {
								$param = substr($fromUrl,strpos($fromUrl,'?'),strlen($fromUrl)-1);
							} else {
								$param = "";
							}
							$url = "PyNiT9GOWR.php".$param;
						?>
						<form method="POST" action="<? echo $url; ?>">
						<table class="table_edit">
						<?
							mysql_connect($host, $user, $password);
							mysql_select_db($db);
							if (isset($_GET["idObject"])) {
								$idObject = $_GET["idObject"];
								$sql = "SELECT "
									." nom,prnom,adresse,codepostal,ville,tlphone,portable"
									.","
									." id_nOXU6aUquV"
								    ." FROM Fiche"
									." WHERE id_nOXU6aUquV=$idObject;";
								$result = mysql_query($sql);
							 	$data = mysql_fetch_array($result);
							 }
						?>
							<tr>
								<td class="property_name">nom</td>
								<td><input 
										type="text" 
										name="nom"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['nom']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">pr�nom</td>
								<td><input 
										type="text" 
										name="prnom"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['prnom']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">adresse</td>
								<td><input 
										type="text" 
										name="adresse"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['adresse']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">code postal</td>
								<td><input 
										type="text" 
										name="codepostal"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['codepostal']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">ville</td>
								<td><input 
										type="text" 
										name="ville"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['ville']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">t�l�phone</td>
								<td><input 
										type="text" 
										name="tlphone"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['tlphone']?>"
										<? } ?>
									/></td>
							</tr>
							<tr>
								<td class="property_name">portable</td>
								<td><input 
										type="text" 
										name="portable"
										<? if (isset($_GET["idObject"])) {?>
										value="<? echo $data['portable']?>"
										<? } ?>
									/></td>
							</tr>
						<?
							$allJoinTable = array(); 
						?>
						</table>
						<input type="hidden" name="table_name" value="Fiche"/>
						<input type="hidden" name="table_fields" value="nom;prnom;adresse;codepostal;ville;tlphone;portable"/>
						<input type="hidden" name="table_relationships" value="<? echo implode(';',$allJoinTable)?>"/>
						<input type="hidden" name="idFieldName" value="id_nOXU6aUquV"/>
						<? if (isset($_GET["idObject"])) {?>
							<input type="hidden" name="updateObject" value="<? echo $data['id_nOXU6aUquV']?>"/>
							<input type="submit" value="Update"/>
						<? } else { ?>
							<input type="hidden" name="createObject" value="1"/>			
							<input type="submit" value="Create"/>
						<? } ?>			
						</form>
					</div>
				<? } ?>
		</div>
	</body>
</html>