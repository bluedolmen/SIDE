-- Script generated
-- Database : reqs_prototype

-- --------------------------------------------------------
--
-- Table structure for table `Carnetdadresse`
--

CREATE TABLE IF NOT EXISTS `Carnetdadresse` (
  `id_MGR7Rpm4rz` int(10) auto_increment,
  PRIMARY KEY  (`id_MGR7Rpm4rz`)
);

--
-- Table structure for table `Rpertoire`
--

CREATE TABLE IF NOT EXISTS `Rpertoire` (
  `id_fp94N3ubdV` int(10) auto_increment,
  `nom` varchar(256) ,
  PRIMARY KEY  (`id_fp94N3ubdV`)
);

--
-- Table structure for table `Fiche`
--

CREATE TABLE IF NOT EXISTS `Fiche` (
  `id_nOXU6aUquV` int(10) auto_increment,
  `nom` varchar(256) ,
  `prnom` varchar(256) ,
  `adresse` varchar(256) ,
  `codepostal` varchar(256) ,
  `ville` varchar(256) ,
  `tlphone` real ,
  `portable` real ,
  PRIMARY KEY  (`id_nOXU6aUquV`)
);

--
-- Table structure for table `Rpertoire2Carnetdadresse`
--

CREATE TABLE IF NOT EXISTS `Rpertoire2Carnetdadresse` (
  `id_fp94N3ubdV` int(10) ,
  `id_MGR7Rpm4rz` int(10) ,
  PRIMARY KEY  (`id_fp94N3ubdV`,`id_MGR7Rpm4rz`)
);

--
-- Table structure for table `Fiche2Rpertoire`
--

CREATE TABLE IF NOT EXISTS `Fiche2Rpertoire` (
  `id_nOXU6aUquV` int(10) ,
  `id_fp94N3ubdV` int(10) ,
  PRIMARY KEY  (`id_nOXU6aUquV`,`id_fp94N3ubdV`)
);

