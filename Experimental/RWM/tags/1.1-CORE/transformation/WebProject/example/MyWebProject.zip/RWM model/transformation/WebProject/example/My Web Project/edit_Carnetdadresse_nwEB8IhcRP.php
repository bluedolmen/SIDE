<html>
	<head>
		<title>Carnet d'adresse</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>
		<? 
			require("./mysql/mysql_util.php");
		?>
		<div id="data">
			<h1>Carnet d'adresse</h1>
				<? if (isset($_GET["Carnetdadresse"])) { ?>	
					<div id="component_create">
						<?
							$fromUrl = $_SERVER['HTTP_REFERER'];
							if (strpos($fromUrl,'?')) {
								$param = substr($fromUrl,strpos($fromUrl,'?'),strlen($fromUrl)-1);
							} else {
								$param = "";
							}
							$url = "nwEB8IhcRP.php".$param;
						?>
						<form method="POST" action="<? echo $url; ?>">
						<table class="table_edit">
						<?
							mysql_connect($host, $user, $password);
							mysql_select_db($db);
							if (isset($_GET["idObject"])) {
								$idObject = $_GET["idObject"];
								$sql = "SELECT "
									." "
									." id_MGR7Rpm4rz"
								    ." FROM Carnetdadresse"
									." WHERE id_MGR7Rpm4rz=$idObject;";
								$result = mysql_query($sql);
							 	$data = mysql_fetch_array($result);
							 }
						?>
						<?
							$allJoinTable = array(); 
						?>
						</table>
						<input type="hidden" name="table_name" value="Carnetdadresse"/>
						<input type="hidden" name="table_fields" value=""/>
						<input type="hidden" name="table_relationships" value="<? echo implode(';',$allJoinTable)?>"/>
						<input type="hidden" name="idFieldName" value="id_MGR7Rpm4rz"/>
						<? if (isset($_GET["idObject"])) {?>
							<input type="hidden" name="updateObject" value="<? echo $data['id_MGR7Rpm4rz']?>"/>
							<input type="submit" value="Update"/>
						<? } else { ?>
							<input type="hidden" name="createObject" value="1"/>			
							<input type="submit" value="Create"/>
						<? } ?>			
						</form>
					</div>
				<? } ?>
		</div>
	</body>
</html>