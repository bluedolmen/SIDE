<html>
	<head>
		<title>Administrer les informations</title>
		<link rel="stylesheet" type="text/css" href="css/main.css">
	</head>
	<body>
		<? 
			require("./mysql/mysql_util.php");
			
			function appendParameter($url, $paramName, $paramValue) {
				$tmp = removeParameter($url,$paramName);
				$separator = "?";
				if (strpos($tmp,"?")!=false)
  					$separator = "&";
 				return $tmp . $separator . "$paramName=$paramValue";
			}
			
			function removeParameter($url, $paramName) {
 				$tmp = ereg_replace("$paramName=([a-zA-Z0-9])*","",$url);
 				$tmp = ereg_replace("\&\&","&",$tmp);
 				$tmp = ereg_replace("\?\&","?",$tmp);
 				return $tmp;
			}
		?>
		<div id="data">
			<h1>Administrer les informations</h1>
					<div id="component">
	<div class="component_title">
	<h2>Carnet d'adresse</h2>
	</div>
			<table>
		<tr>
		</tr>
		<?
				$nbPreviousTable = "Carnetdadresse";
			
			if (isset($pkPreviousTable)) {
				$sql = "SELECT "
					." "
					." id_MGR7Rpm4rz"
					." FROM Carnetdadresse as s"
					." WHERE ("
					."     SELECT COUNT(*)"
					."     WHERE t.id_MGR7Rpm4rz = s.id_MGR7Rpm4rz"
					."     AND t.$pkPreviousTable = \"".$_GET["id$nbPreviousTable"]."\") > 0;";
			} else {
				$sql = "SELECT "
					." "
					." id_MGR7Rpm4rz"
				    ." FROM Carnetdadresse;";
			}
			mysql_connect($host, $user, $password);
			mysql_select_db($db);
			
			$result = mysql_query($sql);
			while ($data = mysql_fetch_array($result) )
			{
				$tableName = "Carnetdadresse";
				if (isset($_GET["id".$tableName]) && $_GET["id".$tableName]==$data["id_MGR7Rpm4rz"]) {
					echo "<tr class=\"line_selected\">\n";
				} else {
					echo "<tr>\n";
				};
		?>
			</tr>
		<?			
			}
			mysql_close();
		?>
	</table>
		<div class="component_create">
		<a href="edit_Carnetdadresse_nwEB8IhcRP.php?viewCarnetdadresse=1&Carnetdadresse=1">Create a new <i>Carnet d'adresse</i></a>
		</div>
</div>
					<? if (isset($_GET['viewCarnetdadresse'])) { ?>
					<div id="component">
						<div class="component_title">
						<h2>Carnet d'adresse</h2>
						</div>
								<table>
							<tr>
							</tr>
							<?
									$nbPreviousTable = "Carnetdadresse";
									$pkPreviousTable = "id_MGR7Rpm4rz";
								
								if (isset($pkPreviousTable)) {
									$sql = "SELECT "
										." "
										." id_MGR7Rpm4rz"
										." FROM Carnetdadresse as s"
										." WHERE ("
										."     SELECT COUNT(*)"
										."     WHERE t.id_MGR7Rpm4rz = s.id_MGR7Rpm4rz"
										."     AND t.$pkPreviousTable = \"".$_GET["id$nbPreviousTable"]."\") > 0;";
								} else {
									$sql = "SELECT "
										." "
										." id_MGR7Rpm4rz"
									    ." FROM Carnetdadresse;";
								}
								mysql_connect($host, $user, $password);
								mysql_select_db($db);
								
								$result = mysql_query($sql);
								while ($data = mysql_fetch_array($result) )
								{
									$tableName = "Carnetdadresse";
									if (isset($_GET["id".$tableName]) && $_GET["id".$tableName]==$data["id_MGR7Rpm4rz"]) {
										echo "<tr class=\"line_selected\">\n";
									} else {
										echo "<tr>\n";
									};
							?>
								</tr>
							<?			
								}
								mysql_close();
							?>
						</table>
							<div class="component_create">
							<a href="edit_Carnetdadresse_nwEB8IhcRP.php?viewCarnetdadresse=1&Carnetdadresse=1">Create a new <i>Carnet d'adresse</i></a>
							</div>
					</div>
					<? } ?>
					<? if (isset($_GET['viewFiche'])) { ?>
					<div id="component">
						<div class="component_title">
						<h2>Fiche</h2>
						</div>
								<table>
							<tr>
								<th>nom</th>
								<th>pr�nom</th>
								<th>adresse</th>
								<th>code postal</th>
								<th>ville</th>
								<th>t�l�phone</th>
								<th>portable</th>
							</tr>
							<?
									$nbPreviousTable = "Carnetdadresse";
									$pkPreviousTable = "id_MGR7Rpm4rz";
								
								if (isset($pkPreviousTable)) {
									$sql = "SELECT "
										." nom,prnom,adresse,codepostal,ville,tlphone,portable"
										.","
										." id_nOXU6aUquV"
										." FROM Fiche as s"
										." WHERE ("
										."     SELECT COUNT(*)"
										."     WHERE t.id_nOXU6aUquV = s.id_nOXU6aUquV"
										."     AND t.$pkPreviousTable = \"".$_GET["id$nbPreviousTable"]."\") > 0;";
								} else {
									$sql = "SELECT "
										." nom,prnom,adresse,codepostal,ville,tlphone,portable"
										.","
										." id_nOXU6aUquV"
									    ." FROM Fiche;";
								}
								mysql_connect($host, $user, $password);
								mysql_select_db($db);
								
								$result = mysql_query($sql);
								while ($data = mysql_fetch_array($result) )
								{
									$tableName = "Fiche";
									if (isset($_GET["id".$tableName]) && $_GET["id".$tableName]==$data["id_nOXU6aUquV"]) {
										echo "<tr class=\"line_selected\">\n";
									} else {
										echo "<tr>\n";
									};
							?>
											<td><? echo $data['nom']; ?></td>
											<td><? echo $data['prnom']; ?></td>
											<td><? echo $data['adresse']; ?></td>
											<td><? echo $data['codepostal']; ?></td>
											<td><? echo $data['ville']; ?></td>
											<td><? echo $data['tlphone']; ?></td>
											<td><? echo $data['portable']; ?></td>
								</tr>
							<?			
								}
								mysql_close();
							?>
						</table>
					</div>
					<? } ?>
					<? if (isset($_GET['viewRpertoire'])) { ?>
					<div id="component">
						<div class="component_title">
						<h2>R�pertoire</h2>
						</div>
								<table>
							<tr>
								<th>nom</th>
								<th>Edit</th>
							</tr>
							<?
									$nbPreviousTable = "Fiche";
									$pkPreviousTable = "id_nOXU6aUquV";
								
								if (isset($pkPreviousTable)) {
									$sql = "SELECT "
										." nom"
										.","
										." id_fp94N3ubdV"
										." FROM Rpertoire as s"
										." WHERE ("
										."     SELECT COUNT(*)"
										."     WHERE t.id_fp94N3ubdV = s.id_fp94N3ubdV"
										."     AND t.$pkPreviousTable = \"".$_GET["id$nbPreviousTable"]."\") > 0;";
								} else {
									$sql = "SELECT "
										." nom"
										.","
										." id_fp94N3ubdV"
									    ." FROM Rpertoire;";
								}
								mysql_connect($host, $user, $password);
								mysql_select_db($db);
								
								$result = mysql_query($sql);
								while ($data = mysql_fetch_array($result) )
								{
									$tableName = "Rpertoire";
									if (isset($_GET["id".$tableName]) && $_GET["id".$tableName]==$data["id_fp94N3ubdV"]) {
										echo "<tr class=\"line_selected\">\n";
									} else {
										echo "<tr>\n";
									};
							?>
											<td><? echo $data['nom']; ?></td>
									<td><a href="edit_Rpertoire_nwEB8IhcRP.php?Rpertoire=1&idObject=<? echo $data['id_fp94N3ubdV']; ?>">Edit</a></td>
								</tr>
							<?			
								}
								mysql_close();
							?>
						</table>
							<div class="component_create">
							<a href="edit_Rpertoire_nwEB8IhcRP.php?viewRpertoire=1&Rpertoire=1">Create a new <i>R�pertoire</i></a>
							</div>
					</div>
					<? } ?>
		</div>
	</body>
</html>